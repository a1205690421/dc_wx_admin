<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/4/12/0012
 * Time: 11:44
 */
include ("../db_connect/db_connect.php");
if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $password=$_POST['password'];
    $temp = new db_connect();
    $temp2=$temp->Adminlogin($name,$password);
    if($temp2==true){
        session_start();
        $_SESSION['username']=$name;
        $_SESSION['password']=$password;
        header("location:../admin.php");
    }
    else{
        header("location:../index.php");
    }



}