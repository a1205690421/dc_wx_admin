<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/4/14/0014
 * Time: 14:33
 */
include ("../db_connect/db_connect.php");
//处理添加优惠券请求
if(isset($_POST['submit'])){
    $name = $_POST['couponName'];
    $couponId = $_POST['couponID'];
    $couponMin =$_POST['couponMin'];
    $couponContent = $_POST['couponContent'];
    $dayofvalid = $_POST['dayofvalid'];


    $couponArray = array($name,$couponId,$couponMin,$couponContent,$dayofvalid);
    $temp = new db_connect();
    $temp2 = $temp->AddCoupon($couponArray);
    if($temp2==true){
       echo "success";

    }
    else{
        echo "fail";
    }


}