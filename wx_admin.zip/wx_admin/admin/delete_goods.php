<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/4/19/0019
 * Time: 16:59
 */
$goodsid=$_GET['goodsid'];
include ("../db_connect/db_connect.php");
$temp = new db_connect();
if($temp->DelectGoodsbyGoodsID($goodsid)){
    echo "删除成功";
}
else{
    echo "删除失败";
}
