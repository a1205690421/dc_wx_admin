<!DOCTYPE html>
<html LANG="cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <title>Document</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="http://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.css" rel="stylesheet" media="screen">
    <script src="http://code.jquery.com/jquery.js"></script>
    <script src="http://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>


<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/4/11/0011
 * Time: 14:33
 */
include ("../db_connect/db_connect.php");
$couponlist = new db_connect();
$res=$couponlist->CouponList();
echo "<table class='table table-bordered text-info table-hover'>",
"<tr><td>序号</td></td><td>优惠券名称</td><td>优惠券编号</td><td>满足金额</td><td>减免金额</td>
<td>有效天数</td><td>已领取的用户</td>
</tr>";
for($i=0;$i<count($res);$i++){
    echo "<tr><td>$i</td>";
    echo "<td>",$res[$i][1],"</td>";
    echo "<td>",$res[$i][2],"</td>";
    echo "<td>",$res[$i][3],"</td>";
    echo "<td>",$res[$i][4],"</td>";
    echo "<td>",$res[$i][5],"</td>";
    echo "</tr>";


}
echo "</table>";
?>

</body>
</html>






