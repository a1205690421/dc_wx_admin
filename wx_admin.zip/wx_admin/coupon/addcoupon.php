<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <title>添加优惠券</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="http://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.css" rel="stylesheet" media="screen">
    <script src="http://code.jquery.com/jquery.js"></script>
    <script src="http://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script>
        function randomString(len) {
            len = len || 32;
            var $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678';    /****默认去掉了容易混淆的字符oOLl,9gq,Vv,Uu,I1****/
            var maxPos = $chars.length;
            var pwd = '';
            for (i = 0; i < len; i++) {
                pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
            }
            return pwd;
        }
        document.getElementById("couponID").value=randomString(10);
        $("#couponID").attr("disabled",false);

    </script>
</head>
<body>



<form class="form-horizontal col-md-offset-4" action="../admin/addcoupon.php"  method="post">
    <fieldset>
        <div id="legend" class="">
            <legend class="">添加优惠券</legend>
        </div>
        <div class="control-group">

            <!-- Text input-->
            <label class="control-label" for="input01">优惠券名称</label>
            <div class="controls">
                <input type="text" placeholder="" class="input-xlarge" name="couponName">
                <p class="help-block">输入优惠券的名称</p>
            </div>
        </div>

        <div class="control-group">
            <!-- Text input-->
            <label class="control-label" for="input01">优惠券编号</label>
            <div class="controls">
                <input type="text" placeholder="" class="input-xlarge" name="couponID" id="couponID">
                <p class="help-block">随机生成，不可输入</p>
            </div>
            <!-- Text input-->
            <label class="control-label" for="input01">满多少可用？</label>
            <div class="controls">
                <input type="text" placeholder="" class="input-xlarge" name="couponMin">
                <p class="help-block">输入最少满足的金额</p>
            </div>
            <!-- Text input-->
            <label class="control-label" for="input01">减免的金额</label>
            <div class="controls">
                <input type="text" placeholder="" class="input-xlarge" name="couponContent">
                <p class="help-block">输入该优惠券欲要减免的金额</p>
            </div>
        </div><div class="control-group">

            <!-- Text input-->
            <label class="control-label" for="input01">有效时间</label>
            <div class="controls">
                <div class="controls"  >
                    <select class="input-xlarge" name="dayofvalid">
                        <option value="1">1天</option>
                        <option value="2">2天</option>
                        <option value="3">3天</option>
                    </select>
                </div>
                <p class="help-block">输入该优惠券自领取之日起的有效时间</p>
            </div>
        </div><div class="control-group">






        <div class="control-group">
            <label class="control-label">提交</label>

            <!-- Button -->
            <div class="controls">
                <button class="btn btn-success" type="submit" name="submit">提交</button>
            </div>
        </div>

    </fieldset>
</form>

<script>
    function randomString(len) {
        len = len || 32;
        var $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678';    /****默认去掉了容易混淆的字符oOLl,9gq,Vv,Uu,I1****/
        var maxPos = $chars.length;
        var pwd = '';
        for (i = 0; i < len; i++) {
            pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
        }
        return pwd;
    }
    document.getElementById("couponID").value=randomString(10);
    document.getElementById("couponID").readOnly=true;



</script>
</body>
</html>