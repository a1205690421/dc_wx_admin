<?php
@session_start();
//$mysql_conf = array(
//    'host'    => 'localhost:3306',
//    'db'      => 'zzjz_test3',
//    'db_user' => 'root',
//    'db_pwd'  => '!@#120lrhLRH',
//);
//$conn = new PDO("mysql:host=" . $mysql_conf['host'] . ";dbname=" . $mysql_conf['db'], $mysql_conf['db_user'], $mysql_conf['db_pwd']);//创建一个pdo对象
//$conn->exec("set names 'utf8'");
//$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
class db_connect{
    private  $host='localhost:3306';
    private  $database="zzjz_test3";
    private  $username='root';
    private  $password='!@#120lrhLRH';
    private  $pdo=null;

    public function  __construct()
    {
        $this->pdo = new PDO("mysql:host=$this->host;dbname=$this->database", $this->username, $this->password);
        $this->pdo->exec("set names 'utf8'");
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    public function  GetGoodsList($page=null){
        //查询数据库中的商品列表
        if($page==null){
            $sql="select * from goods ";
            $result =$this->pdo->prepare($sql);
            $result->execute();
            $row=$result->fetchAll();
            return $row;
        }

        else if($page!=null){
            $sql="select * from goods ".$page->limit;
            $result =$this->pdo->prepare($sql);
            $result->execute();
            $row=$result->fetchAll();
            return $row;
        }

    }
    public function Adminlogin($name,$password){
        //判断管理员账号和密码是否正确
        $sql="select * from admin where login_name=?";
        $result = $this->pdo->prepare($sql);
        $result->bindParam(1,$name);
        $result->execute();
        $row=$result->fetch(PDO::FETCH_ASSOC);
        if($row['login_password']==$password && $password!=null){
            return true;
        }
        else{
            return false;
        }
    }

    public function CouponList(){
        //查询所有的优惠券及其拥有者
        $sql="select * from coupon";
        $relust = $this->pdo->prepare($sql);
        $relust->execute();
        $row=$relust->fetchAll();
        return $row;
    }

    public function UserInfobyOpenid($openid){
        //通过用户的openid来查询用户信息

    }

    public function UserDetail($page=null){
        //查询所有用户信息，不包括手机号码，包括登录时间
        if($page==null){
            $sql="SELECT
	DISTINCT userinfo ,openid,login_time
FROM
	user_login_record 
WHERE
	login_time IN (
		SELECT DISTINCT
			MAX(login_time)
		FROM
			customers a,
			user_login_record b
		WHERE
			a.customerID = b.openid
		GROUP BY
			b.openid
	)";
            $result = $this->pdo->prepare($sql);
            $result->execute();
            $row = $result->fetchAll();
            return $row;
        }
        else{
            $sql="SELECT
	DISTINCT userinfo ,openid,login_time
FROM
	user_login_record 
WHERE
	login_time IN (
		SELECT DISTINCT
			MAX(login_time)
		FROM
			customers a,
			user_login_record b
		WHERE
			a.customerID = b.openid
		GROUP BY
			b.openid
	) ".$page->limit;
            $result = $this->pdo->prepare($sql);
            $result->execute();
            $row = $result->fetchAll();
            return $row;
        }

    }

    public function UserLoginTime($page=null,$openid=null){
        //查询一个用户的所有登录日志
        if($page==null){
            $sql = "SELECT b.userinfo,a.customerID ,a.Phone_Number,a.Email,a.Address,b.login_time FROM
	customers a,user_login_record b WHERE a.customerID = b.openid and b.openid=?";
            $result = $this->pdo->prepare($sql);
            $result->bindParam(1,$openid);
            $result->execute();
            $row = $result->fetchAll();
            return $row;
        }
        else if($page!=null){
            $sql = "SELECT b.userinfo,a.customerID ,a.Phone_Number,a.Email,a.Address,b.login_time FROM
	customers a,user_login_record b WHERE a.customerID = b.openid and b.openid=? ORDER BY login_time desc ".$page->limit;
            $result = $this->pdo->prepare($sql);
            $result ->bindParam(1,$openid);
            $result->execute();
            $row = $result->fetchAll();
            return $row;
        }
    }

    public function AddCoupon($couponArray){
        //添加优惠券，参数是优惠券信息数组
        $sql = "insert into coupon(couponName,couponID,couponMin,couponContent,dayofvalid) values (?,?,?,?,?)";
        $result = $this->pdo->prepare($sql);
        $result->bindParam(1,$couponArray[0]);
        $result->bindParam(2,$couponArray[1]);
        $result->bindParam(3,$couponArray[2]);
        $result->bindParam(4,$couponArray[3]);
        $result->bindParam(5,$couponArray[4]);
        $result->execute();
        if($result->rowCount()==0){
            return false;
        }
        else{

            return true;
        }


    }

    public function AddGoods($goodsdetail){
        //添加商品到数据库中
        $sql = "insert into goods(goodsID,goodsName,goodsTypeID,goodsDescript,goodsUnitPrice,goodsImageName) values (?,?,?,?,?,?)";
        $result = $this->pdo->prepare($sql);
        $result->bindParam(1,$goodsdetail[0]);
        $result->bindParam(2,$goodsdetail[1]);
        $result->bindParam(3,$goodsdetail[2]);
        $result->bindParam(4,$goodsdetail[3]);
        $result->bindParam(5,$goodsdetail[4]);
        $result->bindParam(6,$goodsdetail[5]);
        $result->execute();
        if($result->rowCount()==0){
            return false;
        }
        else{

            return true;
        }


    }

    public function DelectGoodsbyGoodsID($goodsid){
        //通过商品id来删除商品
        $sql = "delete from goods where goodsID=?";
        $result = $this->pdo->prepare($sql);
        $result->bindParam(1,$goodsid);
        $result->execute();
        if($result->rowCount()!=0){
            return true;
        }
        else{
            return false;
        }
    }

    public function AllOrderList($page=null){
        //查看所有订单
        if($page==null){
            $sql ="select * from orders order by orderDate desc ";
            $result = $this->pdo->prepare($sql);
            $result->execute();
            $row=$result->fetchAll();
            return $row;
        }
        else{
            $sql ="select * from orders order by orderDate desc ".$page->limit;
            $result = $this->pdo->prepare($sql);
            $result->execute();
            $row=$result->fetchAll();
            return $row;
        }

    }

    public function CheckUserOrder($page=null,$openid){
        //查看特定用户的所有订单
        if($page==null){
            $sql = "select * from orders where customerID=?";
            $result = $this->pdo->prepare($sql);
            $result->bindParam(1,$openid);
            $result->execute();
            $row=$result->fetchAll();
            return $row;
        }
        else{
            $sql = "select * from orders where customerID=? ".$page->limit;
            $result = $this->pdo->prepare($sql);
            $result->bindParam(1,$openid);
            $result->execute();
            $row=$result->fetchAll();
            return $row;
        }



    }


}