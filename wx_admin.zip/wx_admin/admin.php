<?php
session_start();
if($_SESSION['username']==null){
    header("location:index.php");
    echo "<script>alert('尚未登录，请先登录');</script>";
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>后台管理系统</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/bootstrap.css" rel="stylesheet" media="screen">
    <style>
        body{
            margin:0;
            padding:0;
            font-family: Lato,Helvetica,Arial,sans-serif;
            font-size: 14px;
            line-height: 1.72222;
            color: #34495e;
            background-color: #fff;
        }
        .wrap {
            min-width: 100%;
            position: absolute;
            background: #eff3f6 bottom;
            min-height: 100%;
            overflow: hidden;
        }
        .left{
            margin-left:0px;
            position: absolute;
            box-sizing: border-box;
            width: 200px;
            height: 100%;
            background: #4d5e70 bottom;
        }
        .logoDiv{
            padding-top: 20px;
            padding-bottom: 20px;
            height: 51px;
            background-color: #354457;
            font-size: 17px;
            color: #fff;
            vertical-align: bottom;
        }
        .logoTitle{
            margin-left:15px;
            line-height: 1.7;
        }
        .menu-title {
            margin-left:15px;
            color: #828e9a;
            padding-top: 5px;
            padding-bottom: 5px;
            font-size: 14px;
            font-weight: bold;
        }
        .menu-item {
            padding-left:15px;
            line-height: 40px;
            height: 30px;
            color: #aab1b7;
            cursor: pointer;
        }
        .menu-item-active {
            background-color: #3d4e60;
            border-right: 4px solid #647f9d;
            color: #fff;
        }
        .right{
            box-sizing: border-box;
            float: left;
            box-sizing: border-box;
            padding-left: 200px;
            overflow-y: auto;
            overflow-x: hidden;
            clear: both;
            color: #717592;
            min-width: 100%;
            min-height: 500px;
        }
    </style>
    <script src="http://code.jquery.com/jquery.js"></script>
    <script src="js/bootstrap.js"></script>

</head>
<body>
<div class="wrap">
    <!-- 左边内容 -->
    <div id="left" class="left">
        <div id="logoDiv" class="logoDiv">
            <p id="logoTitle" class="logoTitle">
<!--                <img id="logo" alt="左右布局" src="http://tool.what21.com/page/image/menu/cf.png"-->
<!--                     style="height: 28px; padding-right: 5px;vertical-align: middle;">-->
                <span style="font-size:18px;">后台管理系统</span>
            </p>
        </div>
        <div class="menu-title">商品管理</div>
        <div class="menu-item"  >
            <a href="goods/goodsdetail_test_page.php" target="container">-商品详情</a>
        </div>
        <div class="menu-item" >
            <a href="goods/addgoods.php" target="container">-添加商品</a>
        </div>
        <div class="menu-title">订单管理</div>
        <div class="menu-item" >
            <a href="order/check_ALL_orders.php" target="container">-查看订单</a>
        </div>
        <div class="menu-title">用户管理</div>
        <div class="menu-item" >
            <a href="users/user_detail.php" target="container">-查看用户</a>
        </div>

        <div class="menu-title">优惠券管理</div>
        <div class="menu-item">
            <a href="coupon/couponlist.php" target="container">-查看优惠券</a>
        </div>
        <div class="menu-item">
            <a href="coupon/addcoupon.php" target="container">-添加优惠券</a>
        </div>
        <div class="menu-title">日志记录</div>
        <div class="menu-item">
            <a href="" target="container">-操作日志</a>
        </div>
        <div class="menu-title">数据库管理</div>
        <div class="menu-item" href="#three" data-toggle="tab">
            <a href="" target="container">-查看数据库</a>
        </div>
        <div class="menu-item" href="#three" data-toggle="tab">
            <a href="" target="container">-数据库备份</a>
        </div>
        <div class="menu-title">消息通知</div>
        <div class="menu-item" href="#three" data-toggle="tab">
            <a href="" target="container">-发送消息</a>
        </div>
        <div class="menu-item" href="#three" data-toggle="tab">
            <a href="" target="container">-查看消息</a>
        </div>

    </div>
    <!-- 右边内容 -->
    <div id="right" class="tab-content right">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Brand</a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="#">链接一<span class="sr-only">(current)</span></a></li>
                        <li><a href="#">链接二</a></li>

                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#">欢迎您，<?php session_start();echo $_SESSION['username']?></a></li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="#">Action</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something else here</a></li>
                                <li role="separator" class="divider"></li>
                                <li><a href="#">Separated link</a></li>
                            </ul>
                        </li>
                    </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>
        <iframe name="container" id="fourIfm" frameborder="no" border="0" style="width:100%;"
                src="" scrolling="yes" onload="changeFrameHeight()">
        </iframe>
</div>
</body>
<script>
    $(function() {
        $(".menu-item").click(function() {
            $(".menu-item").removeClass("menu-item-active");
            $(this).addClass("menu-item-active");
            var itmeObj = $(".menu-item").find("img");
            itmeObj.each(function() {
                var items = $(this).attr("src");
                items = items.replace("_grey.png", ".png");
                items = items.replace(".png", "_grey.png")
                $(this).attr("src", items);
            });
            var attrObj = $(this).find("img").attr("src");;
            attrObj = attrObj.replace("_grey.png", ".png");
            $(this).find("img").attr("src", attrObj);
        });
    });
    function changeFrameHeight(){
        var ifm=document.getElementById("fourIfm");
        ifm.height = document.documentElement.clientHeight;
    }
    window.onresize=function(){
        changeFrameHeight();
    }
</script>
</html>