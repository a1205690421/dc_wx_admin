<!DOCTYPE html>
<html LANG="cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <title>Document</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="http://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.css" rel="stylesheet" media="screen">
    <script src="http://code.jquery.com/jquery.js"></script>
    <script src="http://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>



<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/4/17/0017
 * Time: 16:27
 */

include("../db_connect/db_connect.php");
include("../page/page.class.php");
//$openid = $_GET['openid'];
$userlist = new db_connect();
$res=$userlist->AllOrderList();
//var_dump($res);
$total = count($res);
$page = new Page($total,5);
//print_r($page);
$res=$userlist->AllOrderList($page);
//print_r($page->limit);
echo "<table class='table table-bordered text-info table-hover'>",
"<tr><td>订单编号</td><td>用户Openid</td><td>订单内容</td><td>订单时间</td>
<td>所用优惠券</td><td>总价格</td><td>是否出场</td>

</tr>";
for($i=0;$i<count($res);$i++){




    echo "<tr><td>",$res[$i][0],"</td>";
    echo "<td>",$res[$i][1]."&nbsp;","</td><td>";
    foreach(json_decode($res[$i][2],true) as $v) {
        echo "*商品：$v[title]<br/>*图片：<img src='$v[image]' height='50px' width='50px'/><br/>*数量：$v[num]<br/>*单价：$v[price]<br/>---------";
    }
    echo "</td><td>",$res[$i][3]."&nbsp;","</td><td>";
//    echo "<td>",$res[$i][4]."&nbsp;","</td>";
    foreach(json_decode($res[$i][4],true) as $v) {
        echo "*名称：$v[couponName]<br/>*编号：$v[couponID]<br/>*内容：满$v[couponMin]减$v[couponContent]<br/>*有效期：$v[dayofvalid]天<br/>开始日期：$v[startoftime]<br/>结束日期：$v[endoftime]<br/>---------";
    }
    echo "</td><td>",$res[$i][6]."&nbsp;","</td>";
    echo "<td>",$res[$i][7]."&nbsp;","</td>";
    echo "</tr>";


}
echo "</table>";


//调用分页信息
echo "<div>".$page->fpage()."</div>";//里面可以写参数

?>

</body>
</html>