<!DOCTYPE html>
<html LANG="cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <title>Document</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="http://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.css" rel="stylesheet" media="screen">
    <script src="http://code.jquery.com/jquery.js"></script>
    <script src="http://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<?php
$mysql_conf = array(
    'host'    => 'localhost:3306',
    'db'      => 'zzjz_test3',
    'db_user' => 'root',
    'db_pwd'  => '!@#120lrhLRH',
);
include ("../page/page.class.php");
$conn = new PDO("mysql:host=" . $mysql_conf['host'] . ";dbname=" . $mysql_conf['db'], $mysql_conf['db_user'], $mysql_conf['db_pwd']);//创建一个pdo对象
$conn->exec("set names 'utf8'");
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$name = "";
$fytj = "";
if(!empty($_GET["name"]))
{
    $name = $_GET["name"];
    //分页查询条件
    $fytj = "goodsName={$name}";
}
$tj = " where goodsName like '%{$name}%' ";

$sql1= "select count(*) from goods".$tj;
$res=$conn->prepare($sql1);
$res->execute();
$row=$res->fetchAll();
//var_dump($row);
$res_count = $row[0][0];
$page = new Page($res_count,20,$fytj,true);

$sql2 = "select * from goods".$tj.$page->limit;
$res2=$conn->prepare($sql2);
$res2->execute();
$row2=$res2->fetchAll();

echo "查询结果如下：";
echo "<table class='table table-bordered text-info table-hover'>",
"<tr><td>商品编号</td><td>商品名称</td><td>商品类别</td>
<td>商品描述</td><td>商品单价</td><td>商品图片</td>
<td>已经卖出的数量</td>
</tr>";
for($i=0;$i<count($row2);$i++){

    echo "<tr>","<td>",$row2[$i][1]."&nbsp;","</td>";
    echo "<td>",$row2[$i][2]."&nbsp;","</td>";
    echo "<td>",$row2[$i][3]."&nbsp;","</td>";
    echo "<td>",$row2[$i][4]."&nbsp;","</td>";
    echo "<td>",$row2[$i][5]."&nbsp;","</td>";
    echo "<td>",$row2[$i][6]."&nbsp;","</td>";
    echo "<td>",$row2[$i][7]."&nbsp;","</td>";
    echo "</tr>";


}
echo "</table>";
echo $page->fpage();
?>
</body>
</html>
