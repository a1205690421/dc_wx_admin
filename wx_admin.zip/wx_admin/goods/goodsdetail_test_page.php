<!DOCTYPE html>
<html LANG="cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <title>Document</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="http://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.css" rel="stylesheet" media="screen">
    <script src="http://code.jquery.com/jquery.js"></script>
    <script src="http://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div>
    <form action="goodsdetail_search.php" method="get">
        <div>请输入商品名称：
            <input type="text" name="name" value="<?php echo $name ?>" />
            <input type="submit" value="查询" />
        </div>
    </form>
</div>



<?php

/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/4/15/0015
 * Time: 14:41
 */
include ("../db_connect/db_connect.php");
include ("../page/page.class.php");
$goodlist = new db_connect();
$res=$goodlist->GetGoodsList();
//var_dump($res);
$total = count($res);
$page = new Page($total,10);
$res=$goodlist->GetGoodsList($page);
echo "<table class='table table-bordered text-info table-hover'>",
"<tr><td>商品编号</td><td>商品名称</td><td>商品类别</td>
<td>商品描述</td><td>商品单价</td><td>商品图片</td>
<td>更新信息</td><td>删除商品</td>
<td>已经卖出的数量</td>
</tr>";
for($i=0;$i<count($res);$i++){
    $img = $res[$i][6];
    $goodsid = $res[$i][1];
    echo "<tr>","<td>",$res[$i][1],"</td>";
    echo "<td>",$res[$i][2],"</td>";
    echo "<td>",$res[$i][3],"</td>";
    echo "<td>",$res[$i][4],"</td>";
    echo "<td>",$res[$i][5],"</td>";
    echo "<td>","<img src='$img' width='50px' height='50px'/>","</td>";
    echo "<td><a href=''>更新商品信息</a>","</td>";//update
    echo "<td><a href='../admin/delete_goods.php?goodsid=$goodsid''>删除商品</a>","</td>";//delete
    echo "<td>",$res[$i][7],"</td>";
    echo "</tr>";


}
echo "</table>";


    //调用分页信息
    echo "<div>".$page->fpage()."</div>";//里面可以写参数

?>

</body>
</html>
