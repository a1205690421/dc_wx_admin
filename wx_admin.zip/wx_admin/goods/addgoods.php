<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <title>添加商品</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="http://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.css" rel="stylesheet" media="screen">
    <script src="http://code.jquery.com/jquery.js"></script>
    <script src="http://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
<body>



<form class="form-horizontal col-md-offset-4" action="../admin/addgoods.php"  method="post" enctype="multipart/form-data">
    <fieldset>
        <div id="legend" class="">
            <legend class="">添加商品</legend>
        </div>
        <div class="control-group">

            <!-- Text input-->
            <label class="control-label" for="input01">商品名称</label>
            <div class="controls">
                <input type="text" placeholder="" class="input-xlarge" name="goodsName">
                <p class="help-block">输入商品的名称</p>
            </div>
        </div>

        <div class="control-group">
            <!-- Text input-->
            <label class="control-label" for="input01">商品条形码编号</label>
            <div class="controls">
                <input type="text" placeholder="" class="input-xlarge" name="goodsID" >
                <p class="help-block">输入商品的条形码编号</p>
            </div>

            <label class="control-label" for="input01">商品的分类</label>
            <div class="controls">
                <div class="controls"  >
                    <select class="input-xlarge" name="goodsTypeId">
                        <option value="1">1类</option>
                        <option value="2">2类</option>
                        <option value="3">3类</option>
                    </select>
                </div>
                <p class="help-block">输入该商品的分类</p>
            </div>
        </div><div class="control-group">

            <!-- Text input-->
            <label class="control-label" for="input01">商品的描述</label>
            <div class="controls">
                <input type="text" placeholder="" class="input-xlarge" name="goodsDescipt">
                <p class="help-block">输入该商品的描述</p>
            </div>
        </div><div class="control-group">

            <!-- Text input-->
            <label class="control-label" for="input01">商品的售价</label>
            <div class="controls">
                <input type="text" placeholder="" class="input-xlarge" name="goodsUnitPrice">
                <p class="help-block">输入该商品的售价</p>
            </div>
        </div><div class="control-group">

            <!-- File Upload -->
            <div class="controls">
                <input class="input-file" id="fileInput" type="file" name="goodsImage">
            </div>
            <p class="help-block">上传商品图片</p>
        </div>




            <div class="control-group">
                <label class="control-label">提交</label>

                <!-- Button -->
                <div class="controls">
                    <button class="btn btn-success" type="submit" name="submit">提交</button>
                </div>
            </div>

    </fieldset>
</form>


</body>
</html>