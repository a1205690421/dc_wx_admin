<!DOCTYPE html>
<html LANG="cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <title>Document</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="http://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.css" rel="stylesheet" media="screen">
    <script src="http://code.jquery.com/jquery.js"></script>
    <script src="http://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>


<?php

/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/4/15/0015
 * Time: 14:41
 */
include("../db_connect/db_connect.php");
include("../page/page.class.php");
$openid = $_GET['openid'];
$userlist = new db_connect();
$res=$userlist->UserLoginTime(null,$openid);
//var_dump($res);
$total = count($res);

$page = new Page($total,10);
//print_r($page);
$res=$userlist->UserLoginTime($page,$openid);
//print_r($page->limit);
echo "<table class='table table-bordered text-info table-hover'>",
"<tr><td>用户头像</td><td>用户昵称</td><td>用户Openid</td><td>电话号码</td><td>电子邮箱</td>
<td>地址</td><td>上次登录时间</td>

</tr>";
for($i=0;$i<count($res);$i++){
    $userinfo=json_decode($res[$i][0],true);
    $img=$userinfo['avatarUrl'];
    echo "<tr>","<td>","<img src='$img' width='50px' height='50px'/>","</td>";
    echo "<td>",$userinfo['nickName']."&nbsp;","</td>";
    echo "<td>",$res[$i][1]."&nbsp;","</td>";
    echo "<td>",$res[$i][2]."&nbsp;","</td>";
    echo "<td>",$res[$i][3]."&nbsp;","</td>";
    echo "<td>",$res[$i][4]."&nbsp;","</td>";
    echo "<td>",$res[$i][5]."&nbsp;","</td>";
    echo "</tr>";


}
echo "</table>";


//调用分页信息
echo "<div>".$page->fpage()."</div>";//里面可以写参数

?>

</body>
</html>
